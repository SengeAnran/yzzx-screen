# @babel/helper-wrap-function

> Helper to wrap functions inside a function call.

See our website [@babel/helper-wrap-function](https://babeljs.io/docs/en/babel-helper-wrap-function) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-wrap-function
```

or using yarn:

```sh
yarn add @babel/helper-wrap-function --dev
```
