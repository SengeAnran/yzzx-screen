# @babel/plugin-proposal-object-rest-spread

> Compile object rest and spread to ES5

See our website [@babel/plugin-proposal-object-rest-spread](https://babeljs.io/docs/en/babel-plugin-proposal-object-rest-spread) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-object-rest-spread
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-object-rest-spread --dev
```
